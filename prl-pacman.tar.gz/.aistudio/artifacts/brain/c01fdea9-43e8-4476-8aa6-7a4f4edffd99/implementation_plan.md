# Simulador PRL Pac-Man: Planta Industrial y Almacén Logístico

Transformación integral del juego educativo de Prevención de Riesgos Laborales (PRL). Incorpora un motor de física y viraje en cuadrícula con asistencia en esquinas para eliminar cualquier atasco en muros, un rediseño gráfico técnico realista de planta industrial con señalización oficial ISO 7010, un tutorial interactivo guiado para familiarizar al alumno con los conceptos preventivos, y retos evaluativos al recoger Equipos de Protección Individual (EPIs).

## Decisiones Críticas y Preferencias Confirmadas

> [!IMPORTANT]
> Se han consolidado todos los requisitos solicitados:
> - **Tutorial Interactivo Guiado**: Módulo paso a paso previo a la partida que explica mediante metáforas visuales el movimiento seguro, la recolección de *Medidas Preventivas* (puntos amarillos/blancos de seguridad), la activación de *EPIs y Protocolos de Emergencia* (pastillas de poder/equipos) y la evasión o neutralización de *Riesgos Laborales e Incidentes* (fantasmas: riesgo químico, riesgo eléctrico, atropello por carretilla, caída en altura).
> - **Motor de Movimiento y Giro Preciso**: Algoritmo de giro con búfer de comandos, centrado automático en carril de paso (orthogonal auto-snapping) y tolerancia de viraje en esquinas ($\pm 35\%$ de la celda), impidiendo física y matemáticamente que el operario se incruste en las paredes.
> - **Estilo Visual Técnico Realista**: Plano de planta industrial con textura de pavimento epoxi, líneas de tránsito peatonal de seguridad, muros de contención con zócalos de advertencia en franjas diagonales negro/amarillo, señalización oficial ISO 7010 y operario con chaleco reflectante y casco.
> - **Integración Didáctica y Preguntas PRL**: Al recoger EPIs especiales o en fases del tutorial, se plantean preguntas breves con feedback pedagógico inmediato y bonificación de puntos.

---

## 1. Visión General y Concepto Central

- **Propósito**: Herramienta de aprendizaje activo y gamificación para estudiantes de ciclos formativos de PRL y formación continua de empresas.
- **Metáfora Preventiva**:
  - **El Jugador**: Técnico / Operario de PRL en ronda de auditoría de seguridad.
  - **Pastillas Menores**: Medidas Preventivas y Buenas Prácticas (orden y limpieza, señalización de pasillos, revisión de extintores).
  - **Pastillas Mayores (EPIs de Alta Protección)**: Casco, Guantes Dieléctricos, Gafas de Seguridad, Extintor y Arnés anticaídas. Activan el *Protocolo de Seguridad Integral*, permitiendo auditar y neutralizar temporalmente los riesgos.
  - **Fantasmas / Enemigos**: Riesgos e Incidentes de planta (Riesgo Químico/Tóxico, Riesgo Eléctrico, Riesgo Mecánico/Carretilla elevadora, Riesgo de Caída/Atrapamiento).

---

## 2. Experiencia de Usuario y Diseño Visual

### Flujo de Usuario
1. **Acceso y Registro**: Formulario de identificación del alumno (Nombre, Grupo, Ciclo Formativo).
2. **Tutorial Interactivo Paso a Paso**:
   - *Paso 1: Movimiento Seguro*: Aprender a desplazarse por los pasillos de tránsito peatonal delimitados.
   - *Paso 2: Medidas Preventivas*: Recoger las medidas de seguridad básicas.
   - *Paso 3: Identificación de Riesgos*: Reconocer los 4 tipos de riesgos activos en planta y su peligro.
   - *Paso 4: Equipamiento de EPIs y Neutralización*: Recoger un EPI reglamentario, responder una pregunta de PRL y neutralizar el riesgo durante la ventana de protección.
3. **Planta de Operaciones (Gameplay Principal)**:
   - 5 niveles progresivos de inspección con diferentes distribuciones de planta y mayor velocidad de riesgos.
   - Controles fluidos mediante teclado (Flechas / WASD) o D-Pad táctil industrial con feedback háptico.
4. **Informe de Aprovechamiento y Acta Formativa**: Resumen final con puntuación, índice de prevención, preguntas acertadas y opción de reinicio instantáneo o impresión del certificado de aprovechamiento.

### Identidad Visual y Diseño de la Planta
- **Paleta de Colores (60-30-10 y Normativa ISO 7010)**:
  - *60% Fondo*: Pavimento técnico gris oscuro (`#0f172a`, `#1e293b`) con cuadrícula técnica y líneas de marcado vial.
  - *30% Estructuras*: Muros perimetrales con patrón de seguridad amarillo/negro (`#f59e0b` y `#18181b`), racks de almacenamiento y maquinaria estática.
  - *10% Señalización y Acentos*:
    - **Azul Obligación (`#0284c7`)**: Pictogramas redondos de uso obligatorio de EPIs.
    - **Amarillo Advertencia (`#eab308`)**: Triángulos de advertencia de peligro.
    - **Rojo Lucha contra Incendios (`#ef4444`)**: Extintores e hidrantes.
    - **Verde Evacuación (`#10b981`)**: Salidas de socorro y primeros auxilios.
- **Tipografía**: `Plus Jakarta Sans` para textos y títulos, y monoespaciado tabular (`font-mono tabular-nums`) para puntuaciones, temporizadores y métricas de seguridad.

---

## 3. Solución Técnica al Problema de Giros y Colisiones

### Mecánica del "Grid Smooth Cornering Engine"
1. **Separación de Ejes y Detección Predictiva**: En lugar de depender de que las coordenadas flotantes coincidan con el centro exacto de la baldosa, el motor evalúa la cuadrícula discreta de la planta:
   - Si el jugador se desplaza horizontalmente y solicita girar arriba/abajo, se calcula la distancia al centro de la columna más cercana.
   - Si la distancia al centro está dentro del margen de tolerancia ($35\%$ del ancho de casilla), el motor interpola la posición hacia el centro y efectúa el cambio de dirección sin pérdida de velocidad.
2. **Inversión Inmediata de Marcha**: Presionar la dirección contraria invierte el vector de velocidad instantáneamente sin esperar a ninguna esquina.
3. **Resolución de Colisión sin Empotramiento**: El operario nunca avanza más allá del borde de la baldosa transitable; si se aproxima a un muro, se detiene justo en la línea divisoria sin penetrar la pared ni bloquear su capacidad de girar hacia los lados abiertos.
4. **Búfer de Entrada (Input Queueing)**: Guarda la última tecla pulsada durante 250 ms, de modo que si el jugador pulsa la dirección de giro una fracción de segundo antes de la esquina, el giro se ejecuta con precisión milimétrica al abrirse el pasillo.

---

## 4. Arquitectura de Componentes y Datos

```
┌────────────────────────────────────────────────────────────────────────┐
│                        PRL Pacman Safety System                        │
├────────────────────────────────────────────────────────────────────────┤
│  Top Bar (Norma PRL, Nivel, Control de Audio Web Audio API, Alumno)    │
├──────────────────────────────────┬─────────────────────────────────────┤
│        Canvas de Planta 2D       │        Panel de Seguridad HUD       │
│  - Pavimento epoxi y señalética  │  - Identificación del Alumno        │
│  - Operario con alta visibilidad │  - Cascos de Seguridad (Vidas)      │
│  - Riesgos laborales (fantasmas) │  - Marcador de Puntos Preventivos   │
│  - Medidas preventivas y EPIs    │  - EPIs Activos / Temporizador      │
│  - Motor Grid Cornering Engine   │  - Radar de Proximidad de Peligro   │
├──────────────────────────────────┴─────────────────────────────────────┤
│  Tutorial Interactivo Step-by-Step / D-Pad de Control Táctil           │
└────────────────────────────────────────────────────────────────────────┘
                    │                               ▲
                    ▼                               │
         Modal de Preguntas PRL ◄───────────────────┘
         (Banco de preguntas sobre EPIs, extintores,
          ergonomía, orden/limpieza y riesgos de planta)
```

### Plan de Archivos
- `src/types/game.ts`: Tipos de datos para el mapa, jugador, riesgos, EPIs, estado de juego y preguntas de PRL.
- `src/game/physics/MovementEngine.ts`: Motor de movimiento en cuadrícula con suavizado de esquinas, centrado ortogonal y búfer de intención de giro.
- `src/game/render/IndustrialRenderer.ts`: Motor de dibujado en Canvas HTML5 con texturas de pavimento, marcas de advertencia, señalética reglamentaria y animaciones.
- `src/game/audio/SoundSynthesizer.ts`: Sintetizador Web Audio API para efectos de sonido (pisadas en suelo industrial, alarmas de peligro, recogida de medidas preventivas y fanfarrias).
- `src/game/data/quizQuestions.ts`: Banco de preguntas técnicas de prevención de riesgos laborales con retroalimentación explicativa.
- `src/game/data/tutorialSteps.ts`: Pasos guiados del tutorial interactivo con objetivos, resaltado en canvas y mensajes formativos.
- `src/components/PRLTutorialOverlay.tsx`: Componente visual que guía al jugador paso a paso en el tutorial interactivo.
- `src/components/PRLQuizModal.tsx`: Ventana modal para desafíos didácticos de PRL al recoger EPIs.
- `src/components/PRLReportModal.tsx`: Informe final con acta de aprovechamiento para el alumno.
- `src/components/IndustrialHUD.tsx`: Panel de instrumentación y telemetría de seguridad.
- `src/App.tsx`: Ensamblador principal, máquina de estados y gestión de eventos de teclado/táctiles.

---

## 5. Fases de Ejecución

1. **Configuración de Tipos y Preguntas PRL**: Definir estructuras de datos para riesgos, EPIs y preguntas didácticas.
2. **Implementación del Motor de Físicas y Movimiento**: Crear `MovementEngine` para garantizar virajes instantáneos y suaves sin atascos en muros.
3. **Desarrollo del Renderizador Industrial 2D**: Dibujar la planta industrial con pavimento realista, señalización ISO 7010 y operario con equipo reflectante.
4. **Construcción del Tutorial Interactivo**: Implementar la secuencia guiada con objetivos didácticos y mecánicas de aprendizaje.
5. **Implementación de Preguntas de PRL y Modales**: Preguntas con feedback formativo inmediato al equipar EPIs.
6. **Integración de HUD y Audio**: Panel de control industrial, sonido sintetizado con Web Audio API y D-Pad táctil.
7. **Verificación y Compilación**: Pruebas con `compile_applet` para asegurar cero errores de TypeScript y ejecución impecable.
